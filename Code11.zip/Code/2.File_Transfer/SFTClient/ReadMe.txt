1. For Upload write "backslash"+file name from client dir, upload button

2. For DownLoad, choose the file name and put "backslash" before filename, press download button